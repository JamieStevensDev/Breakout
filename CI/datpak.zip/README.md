# laughing-potato
The common scripts and tools for use in assignments
